# LineOps KDS — Deployment Guide

## Requirements

| | Minimum |
|---|---|
| Docker | 24+ |
| Docker Compose | v2 (included in Docker Desktop) |
| RAM | 1 GB |
| Disk | 4 GB |
| OS | Linux, macOS, Windows 10/11, Raspberry Pi OS 64-bit |

---

## One-click start

### Linux / macOS / WSL

```bash
chmod +x start.sh
./start.sh
```

### Windows PowerShell (run as Administrator)

```powershell
.\start.ps1
```

That's it. The script will:
1. Check Docker is available
2. Generate `.env` with random database + session secrets (only on first run)
3. Build and start all containers
4. Print the URL + every LAN IP kitchen tablets can connect to

---

## Services

| Container | Role | Port |
|---|---|---|
| `kds-proxy` | Nginx — single entry point | `:80` (public) |
| `kds-web` | React KDS frontend | internal |
| `kds-api` | Express REST + WebSocket | `:3000` localhost only |
| `kds-db` | PostgreSQL 16 | internal |

All four containers share an isolated Docker network. Only port `:80` is exposed.

---

## POS Integration — Volante VE (Primary)

1. In **VE Back Office → Kitchen Display Setup**, set the KDS URL to:
   `http://<server-ip>/api/integrations/volante/rpc/`
2. Set `VOLANTE_WEBHOOK_SECRET` in `.env` to the same value configured in VE.
3. Set `VOLANTE_STATION_MAP` (JSON) mapping VE KDS Terminal IDs → LineOps station names.
4. Restart: `docker compose restart api`

### Other POS systems

Set the matching `*_WEBHOOK_SECRET` in `.env` and configure the webhook URL in your POS dashboard:

| POS | Endpoint |
|---|---|
| Square | `http://<ip>/api/integrations/square/webhook` |
| Toast | `http://<ip>/api/integrations/toast/webhook` |
| Clover | `http://<ip>/api/integrations/clover/webhook` |
| Lightspeed K | `http://<ip>/api/integrations/lightspeed/webhook` |
| Generic | `http://<ip>/api/integrations/orders` (API key auth) |

---

## Auto-start on boot (Linux / systemd)

```bash
sudo cp docker/lineops-kds.service /etc/systemd/system/
sudo systemctl daemon-reload
sudo systemctl enable --now lineops-kds
```

To also auto-start a kiosk display on the same machine:

```bash
sudo cp docker/lineops-kds-display.service /etc/systemd/system/
sudo systemctl daemon-reload
sudo systemctl enable --now lineops-kds-display
```

---

## Useful commands

```bash
docker compose logs -f          # live logs
docker compose ps               # container status
docker compose restart api      # reload after .env changes
docker compose down             # stop everything
docker compose down -v          # stop + wipe database
```

---

## Changing the port

If port 80 is already in use, edit `.env`:

```
HOST_PORT=8080
```

Then restart: `docker compose up -d`

---

## GitHub

[github.com/abhaypatial/Lineops_KDS](https://github.com/abhaypatial/Lineops_KDS)
