#!/usr/bin/env bash
# LineOps KDS — one-click launcher (Linux / macOS / WSL)
# Requirements: Docker 24+ with the Compose plugin (docker compose)
set -euo pipefail

BOLD="\033[1m"
GREEN="\033[0;32m"
AMBER="\033[0;33m"
RESET="\033[0m"

echo ""
echo -e "${BOLD}LineOps KDS — Docker deploy${RESET}"
echo "──────────────────────────────────────"

# ── Check Docker ─────────────────────────────────────────────────────────────
if ! command -v docker &>/dev/null; then
  echo -e "${AMBER}Docker not found.${RESET}"
  echo "  Install from https://docs.docker.com/get-docker/ and re-run this script."
  exit 1
fi

if ! docker compose version &>/dev/null; then
  echo -e "${AMBER}Docker Compose plugin not found.${RESET}"
  echo "  Install Docker Desktop or run: sudo apt-get install docker-compose-plugin"
  exit 1
fi

echo -e "  Docker: $(docker --version)"

# ── Generate .env from .env.example if missing ──────────────────────────────
if [ ! -f .env ]; then
  echo ""
  echo "  No .env found — generating one with secure random secrets..."
  cp .env.example .env

  DB_PASS=$(LC_ALL=C tr -dc 'A-Za-z0-9_-' </dev/urandom | head -c 32 || true)
  SESSION=$(LC_ALL=C tr -dc 'A-Za-z0-9_-' </dev/urandom | head -c 64 || true)

  # Replace placeholder values
  sed -i.bak "s|DB_PASSWORD=change_me|DB_PASSWORD=${DB_PASS}|" .env
  sed -i.bak "s|SESSION_SECRET=change_me_to_a_long_random_string|SESSION_SECRET=${SESSION}|" .env
  rm -f .env.bak

  echo -e "  ${GREEN}✓ .env created with random secrets${RESET}"
else
  echo "  .env already exists — skipping secret generation"
fi

# ── Pull + build + start ─────────────────────────────────────────────────────
echo ""
echo "  Starting containers (this may take a few minutes on first run)..."
echo ""
docker compose up -d --build --remove-orphans

# ── Print access info ────────────────────────────────────────────────────────
echo ""
echo -e "${GREEN}──────────────────────────────────────${RESET}"
echo -e "${GREEN}  LineOps KDS is running!${RESET}"
echo -e "${GREEN}──────────────────────────────────────${RESET}"
echo ""

HOST_PORT=${HOST_PORT:-80}
echo -e "  Local URL  ${BOLD}http://localhost:${HOST_PORT}/${RESET}"
echo ""

# Show LAN IPs so kitchen displays can connect
if command -v ip &>/dev/null; then
  IPS=$(ip -4 addr show scope global | grep inet | awk '{print $2}' | cut -d/ -f1)
elif command -v ipconfig &>/dev/null; then
  IPS=$(ipconfig 2>/dev/null | grep -i "IPv4" | awk '{print $NF}')
elif command -v ifconfig &>/dev/null; then
  IPS=$(ifconfig 2>/dev/null | grep 'inet ' | awk '{print $2}' | grep -v 127.0.0.1)
fi

if [ -n "${IPS:-}" ]; then
  echo "  LAN addresses (for kitchen display tablets):"
  while IFS= read -r ip; do
    echo -e "    ${BOLD}http://${ip}:${HOST_PORT}/${RESET}"
  done <<< "$IPS"
fi

echo ""
echo "  To stop:   docker compose down"
echo "  Logs:      docker compose logs -f"
echo "  Status:    docker compose ps"
echo ""

# ── Optional: install as systemd service ────────────────────────────────────
if command -v systemctl &>/dev/null; then
  echo "  To start automatically on boot:"
  echo "    sudo cp docker/lineops-kds.service /etc/systemd/system/"
  echo "    sudo systemctl daemon-reload && sudo systemctl enable --now lineops-kds"
  echo ""
fi
