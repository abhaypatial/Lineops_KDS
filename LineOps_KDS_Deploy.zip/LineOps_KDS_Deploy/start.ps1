# LineOps KDS — one-click launcher (Windows PowerShell)
# Requirements: Docker Desktop for Windows with "Use Docker Compose V2" enabled
param(
  [int]$Port = 80
)

$ErrorActionPreference = "Stop"

Write-Host ""
Write-Host "LineOps KDS — Docker deploy" -ForegroundColor White -BackgroundColor DarkBlue
Write-Host "──────────────────────────────────────"

# ── Check Docker ──────────────────────────────────────────────────────────────
try {
  $null = docker --version
} catch {
  Write-Host "ERROR: Docker not found." -ForegroundColor Red
  Write-Host "  Install Docker Desktop from https://www.docker.com/products/docker-desktop/"
  exit 1
}

try {
  $null = docker compose version
} catch {
  Write-Host "ERROR: Docker Compose plugin not found." -ForegroundColor Red
  Write-Host "  Ensure Docker Desktop is up to date and Compose V2 is enabled."
  exit 1
}

Write-Host "  Docker: $(docker --version)"

# ── Generate .env if missing ──────────────────────────────────────────────────
if (-not (Test-Path ".env")) {
  Write-Host ""
  Write-Host "  No .env found — generating with secure random secrets..." -ForegroundColor Yellow
  Copy-Item ".env.example" ".env"

  Add-Type -AssemblyName System.Web
  $dbPass  = [System.Web.Security.Membership]::GeneratePassword(32, 4)
  $session = [System.Web.Security.Membership]::GeneratePassword(64, 8)

  (Get-Content ".env") `
    -replace "DB_PASSWORD=change_me",                           "DB_PASSWORD=$dbPass" `
    -replace "SESSION_SECRET=change_me_to_a_long_random_string","SESSION_SECRET=$session" `
    | Set-Content ".env"

  Write-Host "  .env created with random secrets." -ForegroundColor Green
} else {
  Write-Host "  .env already exists — skipping."
}

# ── Start ─────────────────────────────────────────────────────────────────────
Write-Host ""
Write-Host "  Starting containers (first run may take a few minutes)..."
Write-Host ""
docker compose up -d --build --remove-orphans

# ── Print access info ─────────────────────────────────────────────────────────
Write-Host ""
Write-Host "──────────────────────────────────────" -ForegroundColor Green
Write-Host "  LineOps KDS is running!" -ForegroundColor Green
Write-Host "──────────────────────────────────────" -ForegroundColor Green
Write-Host ""
Write-Host "  Local URL:  http://localhost:$Port/"
Write-Host ""

$ips = (Get-NetIPAddress -AddressFamily IPv4 -PrefixOrigin Dhcp,Manual |
        Where-Object { $_.IPAddress -notlike "169.*" -and $_.IPAddress -ne "127.0.0.1" } |
        Select-Object -ExpandProperty IPAddress)
if ($ips) {
  Write-Host "  LAN addresses (for kitchen tablets):"
  foreach ($ip in $ips) {
    Write-Host "    http://$($ip):$Port/" -ForegroundColor Cyan
  }
}

Write-Host ""
Write-Host "  To stop:   docker compose down"
Write-Host "  Logs:      docker compose logs -f"
Write-Host "  Status:    docker compose ps"
Write-Host ""
